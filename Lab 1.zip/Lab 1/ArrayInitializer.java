//Logan Nestlebush
//CS145
//1/20/2025
//Lab 1
 

public class ArrayInitializer {
    // Method to initialize and return a 2D array
    public double[][] initializeArray(int rows, int columns) {
        return new double[rows][columns];
    }
}
